export JAVA_HOME=./jre
${JAVA_HOME}/bin/java -jar @PKG_NAME@-*.jar
