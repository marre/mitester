The SIP Communicator is currently under active development.
The version you are running is only experimental and WILL NOT 
work as expected. Please refer to
<a href=http://sip-communicator.org>http://sip-communicator.org</a>
for more information.
